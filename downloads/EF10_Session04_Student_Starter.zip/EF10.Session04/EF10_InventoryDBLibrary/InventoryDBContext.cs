using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryDBLibrary;

public class InventoryDbContext : DbContext
{
    // Supplied: pass configuration to EF Core's base class.
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
        : base(options)
    {
    }

    // TODO 02 START - Replace this comment with the Items DbSet property.
    // TODO 02 END
}
