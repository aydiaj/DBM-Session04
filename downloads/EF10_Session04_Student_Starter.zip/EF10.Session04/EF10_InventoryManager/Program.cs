using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

// Adapted from the supplied Practical EF Core 10 activities 01-01 and 03-02.
// The book's host/DI wiring is replaced by a small, supplied configuration block.
Console.WriteLine("DB3 Session 04 - Your first EF Core Inventory query");

try
{
    // Supplied: read appsettings.json from the application's output folder.
    // Environment override keeps optional SQL credentials out of the source files.
    var configuration = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: false)
        .Build();
    string? connectionString = Environment.GetEnvironmentVariable("DBM_EF_CONNECTION")
        ?? configuration.GetConnectionString("InventoryDbConnection");
    if (string.IsNullOrWhiteSpace(connectionString) || connectionString.Contains("YOUR_SERVER"))
    {
        Console.WriteLine("Set the server in TODO 00 (appsettings.json), then complete TODOs 01-05. No database request was made.");
        return;
    }

    // TODO 03 START - Replace the next message with the configuration block.
    Console.WriteLine("Complete TODO 03 to configure EF Core. No database request was made.");
    // TODO 03 END

    // TODO 04 START - Replace this comment with the query, awaited execution,
    // output loop and count. Keep the code INSIDE this try block.
    // TODO 04 END
}
catch (SqlException ex)
{
    Console.WriteLine($"SQL Server error {ex.Number}: {ex.Message}");
    Console.WriteLine("Check the same instance in SSMS, authentication, database setup and preflight. Do not reset the database.");
}
catch (InvalidOperationException ex)
{
    Console.WriteLine($"EF Core configuration/model error: {ex.Message}");
    Console.WriteLine("Check TODOs 01-03: key, DbSet, provider and options.");
}
catch (ArgumentException ex)
{
    Console.WriteLine($"Connection/options error: {ex.Message}");
}
catch (System.IO.IOException ex)
{
    Console.WriteLine($"Configuration file error: {ex.Message}");
}
