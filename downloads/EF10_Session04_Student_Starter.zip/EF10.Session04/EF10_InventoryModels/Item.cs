using System.ComponentModel.DataAnnotations;

namespace EF10_InventoryModels;

public class Item
{
    // TODO 01 START - Replace this comment with the Id and Name properties.
    // TODO 01 END
}
