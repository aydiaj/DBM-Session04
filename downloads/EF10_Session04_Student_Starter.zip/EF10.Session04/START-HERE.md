# Session 04 - First EF Core Inventory query

Classroom adaptation of Practical EF Core 10: Activity 01-01 configuration and Activity 03-02 Inventory model/query. This is not a verbatim copy of the book activity. It uses the book's Item, InventoryDbContext, project names and five movie titles, with fewer moving parts for a first 100-minute lesson.

## Prerequisites

.NET 10 SDK, Visual Studio 2026 with .NET 10 support (or an editor plus CLI), SQL Server and SSMS. `dotnet --list-sdks` must show 10.x. SSMS version is independent of SDK version. NuGet.org access is needed for first restore.

## Start

1. Extract this ZIP. Open EF10InventoryManager.sln. Set EF10_InventoryManager as startup project.
2. In a terminal at this folder run `dotnet restore EF10InventoryManager.sln` and `dotnet build EF10InventoryManager.sln`.
3. Run the COMPLETE setup-inventory.sql in SSMS. This creates the independent InventoryManagerDB_0302 database/table if missing, validates an existing schema, and inserts missing example titles. It preserves existing rows. Run setup once before the query; later use verify-inventory.sql. This supplied support replaces migrations/seeding during Session 04. You are not being assessed on CREATE DATABASE syntax.
4. TODO 00: open EF10_InventoryManager/appsettings.json. Replace YOUR_SERVER with the same server as SSMS. JSON needs two backslashes: a named instance such as .\SQLEXPRESS is written as .\\SQLEXPRESS in the JSON text. Keep the database name InventoryManagerDB_0302.
5. The default uses Windows authentication and local classroom certificate trust. For SQL authentication, set DBM_EF_CONNECTION in your local environment with the instructor's connection string. Do not commit/submit passwords. Production uses a trusted certificate and appropriate authentication.
6. Run `dotnet run --project EF10_InventoryManager`. The untouched starter builds and prints a TODO instruction; it does not contact SQL Server. Configuring only the server still prints the TODO 03 message.

## Complete one task at a time

Keep all supplied code outside TODO regions. Replace only BETWEEN START/END markers:

- TODO 01 in EF10_InventoryModels/Item.cs: add Id and Name properties.
- TODO 02 in EF10_InventoryDBLibrary/InventoryDBContext.cs: add Items DbSet.
- TODO 03 in EF10_InventoryManager/Program.cs: replace the instruction with options, provider and context configuration.
- TODO 04 in Program.cs: insert the query, ToListAsync, loop and count inside try.
- TODO 05 inside TODO 04, before ToListAsync: print query.ToQueryString().

At TODO 03 construction/configuration alone proves no connection. At TODO 04 the awaited query really contacts SQL Server. Top-level statements allow this real await without writing an explicit Task Main method. No dummy await is included.

The solution has one Console Application (EF10_InventoryManager) and two Class Libraries (EF10_InventoryDBLibrary and EF10_InventoryModels). A Class Library builds reusable types into a DLL; run the Console project, not either library. The project references are already prepared: Console -> DBLibrary -> Models. Learn the model/context/query code; host/DI, factories and design-time migration tools are deliberately deferred. Package versions are pinned individually: Microsoft.EntityFrameworkCore.SqlServer 10.0.14, Microsoft.Extensions.Configuration.Json 10.0.14 and System.Security.Cryptography.Pkcs 10.0.13; the supplied book uses 10.0.0 and contains older preview/RC migration snapshots.

## Expected results

Fresh setup: five items, ordered by Name: Star Trek, Star Wars, The Godfather, The Lord of the Rings: The Fellowship of the Ring, Top Gun. Fresh IDs in that order: 3, 2, 4, 5, 1. Existing records/identities/collation can change exact IDs or extra results. Verify against your live SELECT rather than resetting data. The website's Simulated database is a fixed fresh-setup snapshot and does not execute C# or SQL Server.

## Submit

One ZIP named DB3_S04_YourName.zip containing the solution, Directory.Build.props, all three project folders with source/.csproj, password-free appsettings.json, evidence.md and screenshots. Exclude bin, obj, .vs and credentials. Record independent practice in evidence.md and restore the main report before submission.

Do not add migrations, EnsureCreated, EnsureDeleted, Migrate, SaveChanges or related-data loading in this lesson.

## The two starting approaches

Both Code First and Database First use EF Core. The Practical book covers existing-database reverse engineering in Chapter 2 and Code First in Chapter 3. Activity 03-02 is a Code First Inventory project; this lesson adapts its model and query to a prepared existing database. We write the mapping by hand so its meaning is visible. We do not run reverse engineering or migrations in this session. The website shows how both workflows work conceptually.

Use CODE-EXPLAINED.md for the complete line guide, including DataAnnotations, the context constructor, configuration, project references and the supplied SQL setup. A line labelled classroom adaptation is documented as such rather than presented as verbatim book code.

## Corrected cryptography dependency

The database library explicitly references `System.Security.Cryptography.Pkcs` version `10.0.13` to override the vulnerable transitive `9.0.11` version shown in the reported NuGet warning. The Console project receives the updated package through its database-library project reference. The Models project needs no cryptography package. This is dependency maintenance, not an additional coding activity.

After extracting this corrected package into a new folder, restore NuGet packages. To refresh an existing solution from its solution folder, run:

```
dotnet add EF10_InventoryDBLibrary package System.Security.Cryptography.Pkcs --version 10.0.13
dotnet restore EF10InventoryManager.sln --force-evaluate
dotnet list EF10InventoryManager.sln package --include-transitive --vulnerable
```

Confirm NuGet no longer reports Pkcs 9.0.11. Version 10.0.13 is listed as patched in Microsoft's [high-severity advisory](https://github.com/dotnet/runtime/security/advisories/GHSA-846f-f764-76mx) and [moderate-severity advisory](https://github.com/dotnet/runtime/security/advisories/GHSA-2fmv-rv2c-59x7). The actual restored graph and audit must still be checked in the local development environment.
